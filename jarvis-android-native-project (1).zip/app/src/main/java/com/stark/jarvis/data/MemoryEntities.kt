package com.stark.jarvis.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_facts")
data class UserFact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // routine, preference, contact, project
    val fact: String,
    val confidence: Float = 1.0f,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "action_logs")
data class ActionLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actionName: String,
    val parametersJson: String,
    val status: String, // SUCCESS, FAILED, BLOCKED
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_skills")
data class CustomSkill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val triggerPhrase: String,
    val stepsJson: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notification_records")
data class NotificationRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)