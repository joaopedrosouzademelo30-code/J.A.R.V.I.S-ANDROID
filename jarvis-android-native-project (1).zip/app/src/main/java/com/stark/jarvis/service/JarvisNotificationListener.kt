package com.stark.jarvis.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.stark.jarvis.data.JarvisDatabase
import com.stark.jarvis.data.NotificationRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Escuta notificações do Android e permite ao J.A.R.V.I.S.
 * resumir mensagens urgentes e respondê-las com a voz.
 */
class JarvisNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)

    companion object {
        private const val TAG = "JarvisNotifications"
        private val cachedActions = mutableMapOf<String, NotificationCompat.Action>()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName
        // Ignora notificações do próprio Jarvis
        if (packageName == applicationContext.packageName) return

        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (title.isBlank() && text.isBlank()) return

        Log.d(TAG, "Notificação interceptada de $packageName: $title - $text")

        // Armazena e processa no banco de dados para o Briefing
        scope.launch {
            val record = NotificationRecord(
                packageName = packageName,
                title = title,
                content = text,
                timestamp = System.currentTimeMillis()
            )
            JarvisDatabase.getInstance(applicationContext).memoryDao().insertNotification(record)
        }

        // Cache de ação de resposta rápida (Direct Reply)
        extractQuickReplyAction(sbn)
    }

    private fun extractQuickReplyAction(sbn: StatusBarNotification) {
        val actions = NotificationCompat.getActionCount(sbn.notification)
        for (i in 0 until actions) {
            val action = NotificationCompat.getAction(sbn.notification, i)
            if (action?.remoteInputs != null && action.remoteInputs!!.isNotEmpty()) {
                cachedActions[sbn.packageName] = action
                break
            }
        }
    }
}