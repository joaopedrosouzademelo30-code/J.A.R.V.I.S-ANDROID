package com.stark.jarvis.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.stark.jarvis.security.SecurityGatekeeper

/**
 * Automação profunda do Android via AccessibilityService.
 * Permite que o Jarvis inspecione telas de outros aplicativos (WhatsApp, Instagram, etc.),
 * localize elementos visuais, leia textos e realize cliques/rolagens.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "JarvisAccessibility"
        var instance: JarvisAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "JarvisAccessibilityService conectado e pronto para automações.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Monitora transições de janela e eventos de foco
    }

    override fun onInterrupt() {
        Log.w(TAG, "JarvisAccessibilityService interrompido pelo sistema.")
    }

    /**
     * Extrai toda a hierarquia textual visível na tela atual
     */
    fun extractScreenTextHierarchy(): String {
        val rootNode = rootInActiveWindow ?: return "Nenhuma janela ativa detectada."
        val builder = StringBuilder()
        traverseNodes(rootNode, builder, 0)
        return builder.toString()
    }

    private fun traverseNodes(node: AccessibilityNodeInfo?, builder: StringBuilder, depth: Int) {
        if (node == null) return
        val indent = "  ".repeat(depth)
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        val viewId = node.viewIdResourceName

        if (!text.isNullOrEmpty() || !desc.isNullOrEmpty()) {
            builder.append("${indent}[Class: ${node.className}] Text: "${text ?: desc}"")
            if (viewId != null) builder.append(" (id: $viewId)")
            builder.append("
")
        }

        for (i in 0 until node.childCount) {
            traverseNodes(node.getChild(i), builder, depth + 1)
        }
    }

    /**
     * Localiza um nó por texto ou ID e executa clique automatizado
     * Protegido pelo SecurityGatekeeper (requer autenticação biométrica prévia)
     */
    fun performClickOnTarget(targetText: String): Boolean {
        if (!SecurityGatekeeper.isActionPermitted("automate_screen_click")) {
            Log.e(TAG, "Ação de clique bloqueada pelo Security Gatekeeper.")
            return false
        }

        val rootNode = rootInActiveWindow ?: return false
        val matchedNodes = rootNode.findAccessibilityNodeInfosByText(targetText)

        for (node in matchedNodes) {
            if (node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            // Tenta clicar no ancestral clicável
            var parent = node.parent
            while (parent != null) {
                if (parent.isClickable) {
                    return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                parent = parent.parent
            }
        }

        // Se nó não for clicável, dispara gesto simulado nas coordenadas da tela
        if (matchedNodes.isNotEmpty()) {
            val rect = Rect()
            matchedNodes[0].getBoundsInScreen(rect)
            return dispatchClickGesture(rect.centerX().toFloat(), rect.centerY().toFloat())
        }
        return false
    }

    /**
     * Dispara um toque gestual nas coordenadas exatas da tela
     */
    fun dispatchClickGesture(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}