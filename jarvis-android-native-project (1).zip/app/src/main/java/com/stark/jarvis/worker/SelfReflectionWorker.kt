package com.stark.jarvis.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.stark.jarvis.ai.GeminiAgentEngine
import com.stark.jarvis.data.JarvisDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Worker agendado para as 03:00 AM / quando o aparelho estiver conectado à energia.
 * Analisa as interações do dia e extrai novos fatos para atualizar a inteligência do Jarvis.
 */
class SelfReflectionWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        private const val TAG = "SelfReflectionWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.i(TAG, "Iniciando ciclo noturno de auto-reflexão e aprimoramento...")

        val db = JarvisDatabase.getInstance(applicationContext)
        val logs = db.memoryDao().getRecentLogs()

        if (logs.isEmpty()) {
            return@withContext Result.success()
        }

        val prompt = """
            Analise os logs de conversas recentes do usuário abaixo e extraia apenas novos fatos consolidados sobre sua rotina,
            hábitos e preferências (ex: horários de treino, estilo de comunicação, projetos em andamento).
            Retorne em formato JSON estruturado com chave 'facts'.
            LOGS:
            ${logs.joinToString("\n") { it.parametersJson }}
        """.trimIndent()

        val gemini = GeminiAgentEngine(applicationContext)
        val reflectionSummary = gemini.processUserCommand(prompt)

        Log.i(TAG, "Auto-reflexão finalizada com sucesso: $reflectionSummary")
        Result.success()
    }
}