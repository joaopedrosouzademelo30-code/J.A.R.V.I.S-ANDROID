package com.stark.jarvis.ai

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.net.URLEncoder

/**
 * Agente Web que navega na internet, realiza buscas e extrai conteúdo limpo
 * removendo scripts, propagandas e estilos.
 */
object WebSearchAndScrapeTool {

    private const val TAG = "WebSearchAndScrapeTool"
    private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    suspend fun executeSearchOrScrape(queryOrUrl: String): String = withContext(Dispatchers.IO) {
        try {
            if (queryOrUrl.startsWith("http://") || queryOrUrl.startsWith("https://")) {
                scrapeDirectUrl(queryOrUrl)
            } else {
                searchDuckDuckGoClean(queryOrUrl)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro na raspagem web", e)
            "Não foi possível obter dados da web: ${e.message}"
        }
    }

    private fun scrapeDirectUrl(url: String): String {
        val doc = Jsoup.connect(url)
            .userAgent(USER_AGENT)
            .timeout(10000)
            .get()

        // Remove ruídos da página
        doc.select("script, style, nav, footer, iframe, noscript, .ad, .banner").remove()
        val text = doc.body().text()
        return if (text.length > 2500) text.substring(0, 2500) + "... [conteúdo truncado]" else text
    }

    private fun searchDuckDuckGoClean(query: String): String {
        val searchUrl = "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(query, "UTF-8")
        val doc = Jsoup.connect(searchUrl)
            .userAgent(USER_AGENT)
            .timeout(12000)
            .get()

        val results = doc.select(".result__body")
        val sb = StringBuilder("Resultados da Busca Web para '$query':\n")

        for ((index, element) in results.take(3).withIndex()) {
            val title = element.select(".result__title").text()
            val snippet = element.select(".result__snippet").text()
            sb.append("${index + 1}. $title\n   $snippet\n\n")
        }

        return sb.toString()
    }
}