package com.stark.jarvis.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface MemoryDao {

    @Query("SELECT * FROM user_facts ORDER BY timestamp DESC")
    suspend fun getAllFacts(): List<UserFact>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFact(fact: UserFact)

    @Query("DELETE FROM user_facts WHERE id = :id")
    suspend fun deleteFact(id: Long)

    @Query("SELECT * FROM action_logs ORDER BY timestamp DESC LIMIT 100")
    suspend fun getRecentLogs(): List<ActionLog>

    @Insert
    suspend fun insertLog(log: ActionLog)

    @Query("SELECT * FROM custom_skills")
    suspend fun getAllSkills(): List<CustomSkill>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSkill(skill: CustomSkill)

    @Insert
    suspend fun insertNotification(record: NotificationRecord)

    @Query("SELECT * FROM notification_records WHERE timestamp > :sinceTime ORDER BY timestamp DESC")
    suspend fun getUnreadNotifications(sinceTime: Long): List<NotificationRecord>
}