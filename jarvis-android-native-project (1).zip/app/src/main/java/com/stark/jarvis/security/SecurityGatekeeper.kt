package com.stark.jarvis.security

import android.content.Context
import android.util.Log
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Security Gatekeeper:
 * Garante que ações de Nível 2 (críticas) passem por autenticação biométrica,
 * e controla o protocolo de emergência Kill Switch.
 */
object SecurityGatekeeper {

    private const val TAG = "SecurityGatekeeper"
    var isKillSwitchActive: Boolean = false
        private set

    private val CRITICAL_ACTIONS = setOf(
        "send_message",
        "make_phone_call",
        "automate_screen_click",
        "delete_file_or_data",
        "update_security_settings",
        "execute_financial_transaction"
    )

    fun isActionCritical(actionName: String): Boolean {
        return CRITICAL_ACTIONS.contains(actionName)
    }

    fun isActionPermitted(actionName: String): Boolean {
        if (isKillSwitchActive) {
            Log.w(TAG, "Tentativa de ação bloqueada: Kill Switch ativo!")
            return false
        }
        if (isActionCritical(actionName)) {
            // Requer verificação biométrica em tempo de execução
            return false
        }
        return true
    }

    fun triggerKillSwitch(context: Context) {
        isKillSwitchActive = true
        Log.e(TAG, "PROTOCOLO DE BLOQUEIO ACIONADO. Todos os sensores e atuadores pausados.")
    }

    fun deactivateKillSwitch() {
        isKillSwitchActive = false
        Log.i(TAG, "Protocolo de bloqueio desativado. Sistemas restaurados.")
    }

    /**
     * Dispara o BiometricPrompt nativo do Android
     */
    fun requestBiometricConfirmation(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                Log.i(TAG, "Biometria validada com sucesso.")
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                Log.e(TAG, "Falha biométrica: $errString")
                onError(errString.toString())
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()

        prompt.authenticate(promptInfo)
    }
}