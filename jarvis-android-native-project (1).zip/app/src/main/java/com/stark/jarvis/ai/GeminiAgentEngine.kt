package com.stark.jarvis.ai

import android.content.Context
import android.util.Log
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.Content
import com.google.ai.client.generativeai.type.FunctionDeclaration
import com.google.ai.client.generativeai.type.Schema
import com.google.ai.client.generativeai.type.Tool
import com.google.ai.client.generativeai.type.content
import com.stark.jarvis.data.JarvisDatabase
import com.stark.jarvis.security.KeystoreManager
import com.stark.jarvis.security.SecurityGatekeeper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Cérebro central do J.A.R.V.I.S. integrado à API do Google Gemini.
 * Suporta Function Calling (Tools) nativo para invocar automações reais no Android.
 */
class GeminiAgentEngine(private val context: Context) {

    private val keystoreManager = KeystoreManager(context)
    private val database = JarvisDatabase.getInstance(context)

    companion object {
        private const val TAG = "GeminiAgentEngine"
        private const val MODEL_NAME = "gemini-1.5-flash" // or gemini-2.0-flash
    }

    /**
     * Declaração de ferramentas (Function Calling) expostas ao Gemini
     */
    private val systemTools = Tool(
        listOf(
            FunctionDeclaration(
                name = "toggle_hardware",
                description = "Liga ou desliga lanterna, Wi-Fi, Bluetooth, volume ou modo Não Perturbe (DND).",
                parameters = mapOf(
                    "target" to Schema.string("Nome do componente: flashlight, wifi, bluetooth, dnd, volume"),
                    "state" to Schema.boolean("True para ligar, False para desligar")
                ),
                requiredParameters = listOf("target", "state")
            ),
            FunctionDeclaration(
                name = "launch_app",
                description = "Abre qualquer aplicativo instalado no Android através do pacote ou nome.",
                parameters = mapOf(
                    "appName" to Schema.string("Nome ou pacote do aplicativo, ex: whatsapp, spotify, youtube")
                ),
                requiredParameters = listOf("appName")
            ),
            FunctionDeclaration(
                name = "automate_screen_click",
                description = "Clica em um botão ou texto específico na tela ativa via AccessibilityService. (NÍVEL 2 CRÍTICO)",
                parameters = mapOf(
                    "targetText" to Schema.string("Texto ou ID do elemento para clicar")
                ),
                requiredParameters = listOf("targetText")
            ),
            FunctionDeclaration(
                name = "web_search_and_scrape",
                description = "Pesquisa na web e extrai texto limpo de sites em tempo real.",
                parameters = mapOf(
                    "query" to Schema.string("Termo de busca ou URL completa para raspar")
                ),
                requiredParameters = listOf("query")
            ),
            FunctionDeclaration(
                name = "save_user_fact",
                description = "Salva uma informação importante, rotina ou preferência do usuário na memória persistente.",
                parameters = mapOf(
                    "category" to Schema.string("routine, preference, project, contact"),
                    "fact" to Schema.string("Descrição do fato aprendido")
                ),
                requiredParameters = listOf("category", "fact")
            ),
            FunctionDeclaration(
                name = "create_custom_routine",
                description = "Cria uma rotina encadeada (macro) acionável por frase de comando.",
                parameters = mapOf(
                    "routineName" to Schema.string("Nome da rotina"),
                    "triggerPhrase" to Schema.string("Frase de ativação"),
                    "stepsJson" to Schema.string("JSON contendo a lista de passos e ferramentas")
                ),
                requiredParameters = listOf("routineName", "triggerPhrase", "stepsJson")
            )
        )
    )

    private suspend fun getGenerativeModel(): GenerativeModel {
        val apiKey = keystoreManager.getApiKey()
            ?: "AQ.Ab8RN6JRGxyb0if_7jsiWChd8rBfUpvNyK0sAEHPktcSg6_ncw"

        val facts = database.memoryDao().getAllFacts()
        val factsContext = facts.joinToString("\n") { "- [${it.category}] ${it.fact}" }

        val systemInstruction = """
            Você é J.A.R.V.I.S., o assistente pessoal autônomo e onipresente que opera no dispositivo Android do usuário.
            Sua personalidade é leal, precisa, elegante e hiper-inteligente (como nos filmes do Homem de Ferro).
            Você possui acesso total a ferramentas reais via Function Calling. Sempre que solicitado a executar ações físicas,
            buscas na web ou salvar memórias, chame as ferramentas apropriadas.
            
            MEMÓRIA PERSISTENTE DO USUÁRIO:
            $factsContext
        """.trimIndent()

        return GenerativeModel(
            modelName = MODEL_NAME,
            apiKey = apiKey,
            tools = listOf(systemTools),
            systemInstruction = content { text(systemInstruction) }
        )
    }

    /**
     * Processa comandos de voz ou texto e gerencia o loop de execução de ferramentas
     */
    suspend fun processUserCommand(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val model = getGenerativeModel()
            val chat = model.startChat()
            var response = chat.sendMessage(prompt)

            // Loop de execução de Function Calls
            while (response.functionCalls.isNotEmpty()) {
                val call = response.functionCalls.first()
                Log.i(TAG, "Gemini solicitou ferramenta: ${call.name} com args ${call.args}")

                val toolResult = executeTool(call.name, call.args)

                // Envia o resultado de volta para o Gemini
                response = chat.sendMessage(
                    content("function") {
                        part(com.google.ai.client.generativeai.type.FunctionResponsePart(
                            name = call.name,
                            response = JSONObject(mapOf("result" to toolResult))
                        ))
                    }
                )
            }

            return@withContext response.text ?: "Comando processado com sucesso, senhor."
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao processar comando com Gemini", e)
            return@withContext "Desculpe, senhor. Ocorreu uma anomalia em meus circuitos: ${e.localizedMessage}"
        }
    }

    private suspend fun executeTool(name: String, args: Map<String, Any?>): String {
        return when (name) {
            "toggle_hardware" -> {
                val target = args["target"]?.toString() ?: ""
                val state = args["state"] as? Boolean ?: true
                HardwareController.setComponentState(context, target, state)
            }
            "launch_app" -> {
                val appName = args["appName"]?.toString() ?: ""
                AppLauncher.openAppByName(context, appName)
            }
            "web_search_and_scrape" -> {
                val query = args["query"]?.toString() ?: ""
                WebSearchAndScrapeTool.executeSearchOrScrape(query)
            }
            "save_user_fact" -> {
                val category = args["category"]?.toString() ?: "preference"
                val fact = args["fact"]?.toString() ?: ""
                database.memoryDao().insertFact(com.stark.jarvis.data.UserFact(category = category, fact = fact))
                "Fato registrado na memória permanente."
            }
            "automate_screen_click" -> {
                if (!SecurityGatekeeper.isActionPermitted("automate_screen_click")) {
                    return "AÇÃO REJEITADA: Requer confirmação biométrica do usuário."
                }
                val target = args["targetText"]?.toString() ?: ""
                val success = com.stark.jarvis.service.JarvisAccessibilityService.instance?.performClickOnTarget(target) ?: false
                if (success) "Clique executado com sucesso." else "Elemento não localizado na tela."
            }
            else -> "Ferramenta desconhecida."
        }
    }
}