package com.stark.jarvis.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stark.jarvis.ui.theme.*

@Composable
fun JarvisDashboardScreen(
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    var isListening by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StarkDarkBg)
            .padding(16.dp)
    ) {
        // Top HUD Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "J.A.R.V.I.S.",
                    color = CyanStark,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "MARK VII • ANDROID NEURAL CORE",
                    color = CyanStark.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }

            // Status Badge 24/7
            Surface(
                color = GreenStatus.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GreenStatus)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(GreenStatus, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ONLINE 24/7", color = GreenStatus, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Arc Reactor Central Visualizer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp),
            contentAlignment = Alignment.Center
        ) {
            ArcReactorVisualizerComponent(isActive = isListening)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = CyanStark,
            divider = {}
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("HUD & COMANDOS") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("MEMÓRIA ROOM") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("SENSORES") })
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedTab) {
            0 -> JarvisCommandConsole()
            1 -> JarvisMemoryInspector()
            2 -> JarvisSensorsMonitor()
        }
    }
}

@Composable
fun ArcReactorVisualizerComponent(isActive: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_rotation")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Canvas(modifier = Modifier.size(190.dp)) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = size.minDimension / 2

        // Outer Ring
        drawCircle(
            color = CyanStark.copy(alpha = 0.3f),
            radius = radius,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )

        // Middle Glowing Segments
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(CyanStark.copy(alpha = 0.4f), Color.Transparent),
                center = center,
                radius = radius * 0.8f
            ),
            radius = radius * 0.75f,
            center = center
        )

        // Core Inner Ring
        drawCircle(
            color = if (isActive) CyanStark else Color.Gray,
            radius = radius * 0.35f,
            center = center,
            style = Stroke(width = 4.dp.toPx())
        )
    }
}

@Composable
fun JarvisCommandConsole() {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF07111E),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyanStark.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                "TERMINAL NEURAL DE COMANDOS",
                color = CyanStark,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "JARVIS: "Às suas ordens, senhor. Todos os subsistemas e ferramentas do dispositivo estão sincronizados."",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun JarvisMemoryInspector() {
    Text("Memórias persistidas no Room Database (UserFacts, CustomSkills).", color = CyanStark)
}

@Composable
fun JarvisSensorsMonitor() {
    Text("Status de Acessibilidade, Notificações, Áudio e Câmera.", color = CyanStark)
}