package com.stark.jarvis.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.stark.jarvis.R
import com.stark.jarvis.ai.WakeWordDetector
import com.stark.jarvis.security.SecurityGatekeeper
import com.stark.jarvis.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Serviço de Primeiro Plano 24/7 com alta resiliência.
 * Mantém o J.A.R.V.I.S. ativo continuamente, com WakeLock parcial
 * e notificação persistente contendo botão de Pânico (Kill Switch).
 */
class JarvisForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeWordDetector: WakeWordDetector? = null

    companion object {
        private const val TAG = "JarvisForegroundService"
        const val CHANNEL_ID = "jarvis_24_7_channel"
        const val NOTIFICATION_ID = 1007
        const val ACTION_START = "ACTION_START_JARVIS"
        const val ACTION_STOP = "ACTION_STOP_JARVIS"
        const val ACTION_KILL_SWITCH = "ACTION_KILL_SWITCH"

        var isRunning: Boolean = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Inicializando J.A.R.V.I.S. Core Foreground Service...")
        createNotificationChannel()
        acquireWakeLock()
        initWakeWordListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_KILL_SWITCH -> {
                Log.w(TAG, "Protocolo de Bloqueio (Kill Switch) acionado pela notificação!")
                SecurityGatekeeper.triggerKillSwitch(this)
                updateNotification(isLocked = true)
            }
            ACTION_STOP -> {
                stopForegroundService()
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildPersistentNotification(isLocked = false))
                isRunning = true
                wakeWordDetector?.startListening()
            }
        }
        // START_STICKY garante que o sistema reinicie o serviço caso seja morto sob pressão extrema
        return START_STICKY
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "JARVIS::ContinuousBackgroundWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
        Log.i(TAG, "WakeLock 24/7 adquirido com sucesso.")
    }

    private fun initWakeWordListener() {
        wakeWordDetector = WakeWordDetector(this) {
            Log.i(TAG, "Palavra de ativação 'JARVIS' detectada localmente!")
            serviceScope.launch {
                // Inicia STT e envia ao Gemini Agent Engine
                JarvisAudioOrchestrator.onWakeWordTriggered(applicationContext)
            }
        }
    }

    private fun buildPersistentNotification(isLocked: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val killSwitchIntent = Intent(this, JarvisForegroundService::class.java).apply {
            action = ACTION_KILL_SWITCH
        }
        val killSwitchPendingIntent = PendingIntent.getService(
            this, 1, killSwitchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val title = if (isLocked) "J.A.R.V.I.S. [PROTOCOLO DE BLOQUEIO ATIVO]" else "J.A.R.V.I.S. Operacional (24/7)"
        val statusText = if (isLocked) "Sensores desativados por segurança." else "Escuta ativa e prontidão de sistemas."

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_jarvis_reactor)
            .setContentTitle(title)
            .setContentText(statusText)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(pendingIntent)
            .addAction(
                R.drawable.ic_lock_emergency,
                if (isLocked) "Desbloquear" else "KILL SWITCH",
                killSwitchPendingIntent
            )
            .build()
    }

    private fun updateNotification(isLocked: Boolean) {
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.notify(NOTIFICATION_ID, buildPersistentNotification(isLocked))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "J.A.R.V.I.S. Status 24/7",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Canal persistente para manter o J.A.R.V.I.S. ativo dia e noite"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopForegroundService() {
        isRunning = false
        wakeWordDetector?.stopListening()
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        serviceScope.cancel()
        wakeWordDetector?.stopListening()
        wakeLock?.let { if (it.isHeld) it.release() }
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}