package com.stark.jarvis.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val StarkDarkBg = Color(0xFF030712)
val CyanStark = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF0070F3)
val GreenStatus = Color(0xFF00E676)
val OrangeWarning = Color(0xFFFF9100)
val RedEmergency = Color(0xFFFF1744)

private val DarkColorScheme = darkColorScheme(
    primary = CyanStark,
    secondary = ElectricBlue,
    background = StarkDarkBg,
    surface = Color(0xFF0A101D),
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = CyanStark
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}