# J.A.R.V.I.S. — Assistente Pessoal Autônomo 24/7 para Android

Aplicativo Android nativo construído em **Kotlin** e **Jetpack Compose**, operando como um Agente de IA com **Google Gemini** e Function Calling para controle do dispositivo.

---

## ⚡ Passo a Passo para Compilar o APK no Android Studio

1. **Baixar o Projeto:**
   - Clique no botão **"Baixar Projeto Android Completo (.ZIP)"** no painel do J.A.R.V.I.S.
   - Extraia o arquivo zip em seu computador.

2. **Abrir no Android Studio:**
   - Abra o **Android Studio (versão Ladybug / Koala / Hedgehog ou superior)**.
   - Selecione **File > Open** e escolha a pasta extraída.
   - Aguarde a sincronização automática do Gradle (Gradle Sync).

3. **Gerar o APK (.apk):**
   - No menu superior, clique em:
     `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   - Ou execute no terminal do Android Studio:
     ```bash
     ./gradlew assembleDebug
     ```
   - O arquivo APK será gerado em:
     `app/build/outputs/apk/debug/app-debug.apk`

4. **Instalar no Dispositivo Físico:**
   - Conecte o celular via cabo USB com **Depuração USB** ativada.
   - Clique no botão verde de **Run (Shift + F10)** ou instale com:
     ```bash
     adb install app/build/outputs/apk/debug/app-debug.apk
     ```

---

## 🔒 Ativação das Permissões no Celular

Para o J.A.R.V.I.S. funcionar 24 horas por dia com controle profundo do aparelho, ative as seguintes configurações no primeiro uso:

1. **Acessibilidade:**
   - Vá em *Configurações > Acessibilidade > Aplicativos Instalados > J.A.R.V.I.S.* e ative o serviço.
2. **Acesso a Notificações:**
   - Em *Configurações > Notificações > Acesso Especial a Notificações*, habilite o *J.A.R.V.I.S. Notification Bridge*.
3. **Isenção de Bateria (24/7 sem interrupção):**
   - O app solicitará a isenção de economia de bateria automaticamente ao abrir. Confirme permitindo rodar em segundo plano sem restrições.
4. **Sobrepor a outros aplicativos (Overlay HUD):**
   - Ative a permissão *Aparecer sobre outros apps* para o display holográfico flutuante.